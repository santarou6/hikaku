﻿
var fp = new Array();
var A = new Array();
var B = new Array();
var N;
var M;
var mC = new Array();

    $(document).ready(function(){
        $("#names").html("<p>ここをクリック！</p>");
        $("#ss1").val(sample_txt[0].t);
        $("#ss2").val(sample_txt[1].t);
        $('#names').click(function(e){
            //$("#ss1").val(JSON.stringify($("#ss2").val()));
            mC = new Array();
            s1 = $("#ss1").val();
            s2 = $("#ss2").val();
            diffx(s1, s2);
            var qa,qb;
            if(s1.length<=s2.length){
              qa = 1;
              qb = 2;
            }else{
              qa = 2;
              qb = 1;
            }
            var aa = mC.join("").split("\n");
            $("#sat1").html("");
            for(var i = 0, len = aa.length; i < len; ++i){
              $("#sat1").append("<tr><td class=d"+qa+">" + aa[i] + "</td><td class=d"+qb+">" + aa[i] + "</td></tr>");
            }
            /**/
        });

    }); 

function diffx(c1r, c2r){
  var A = c1r.split('');
  var B = c2r.split('');
  var M = A.length;
  var N = B.length;

  var exchanged = false;

  if(N > M){
    exchanged = true;
    var t;
    t = A;
    A = B;
    B = t;
    t = M;
    M = N;
    N = t;
  }

  var offset = N;
  var delta = M - N;
  var size = M + N + 1;
  for(var i = 0, fp = []; i < size; ++i){
    fp[i] = {
      y    : null,
      tree : null
    }
  }
  var snake = function(k){
    if((k < -N) || (M < k)){
      return;
    } else {
      var current = fp[k+offset];
      if(k === -N){
        var down  = fp[k+1+offset];
        current.y = down.y+1;
        current.tree = {
          type : '+',
          prev : down.tree
        }
      } else if(k === M){
        var slide = fp[k-1+offset];
        current.y = slide.y;
        current.tree = {
          type : '-',
          prev : slide.tree
        }
      } else {
        var slide = fp[k-1+offset];
        var down  = fp[k+1+offset];
        if(slide.y === null && down.y === null){
          current.y = 0;
        } else if(down.y === null || slide.y === null){
          if(down.y === null){
            current.y = slide.y;
            current.tree = {
              type : '-',
              prev : slide.tree
            }
          } else {
            current.y = down.y+1;
            current.tree = {
              type : '+',
              prev : down.tree
            }
          }
        } else {
          if(slide.y > (down.y+1)){
            current.y = slide.y;
            current.tree = {
              type : '-',
              prev : slide.tree
            }
          } else {
            current.y = down.y+1;
            current.tree = {
              type : '+',
              prev : down.tree
            }
          }
        }
      }
      var y = current.y;
      var x = y + k;
      while(x < M && y < N && A[x] === B[y]){
        current.tree = {
          type : '|',
          prev : current.tree
        }
        x++;
        y++;
      }
      current.y = y;
    }
  }

  var p = -1,
      k =  0;
  while(fp[delta+offset].y < N){
    p = p + 1;
    for(k = -p; k < delta; ++k){
      snake(k);
    }
    for(k = delta+p; k > delta; --k){
      snake(k);
    }
    snake(delta);
  }

  var current = fp[delta+offset];
  current.d = delta + 2 * p;
  var type = null, a_index = M - 1, b_index = N - 1;
  for(var i = current.tree; i != null; i = i.prev){
    type = i.type;
    if(type === '+'){
      mC.unshift('<em class=c2>'+ B[b_index] + "</em>");
      --b_index;
    } else if(type === '-'){
      mC.unshift('<em class=c1>'+ A[a_index] + "</em>");
      --a_index;
    } else {
      mC.unshift(A[a_index] );
      --a_index;
      --b_index;
    }
  }
}

/*
 参考URL

1.
http://www.itu.dk/stud/speciale/bepjea/xwebtex/litt/an-onp-sequence-comparison-algorithm.pdf
2.
http://hp.vector.co.jp/authors/VA007799/viviProg/doc5.htm
3.
http://coding.derkeiler.com/Archive/General/comp.programming/2004-04/0966.html
4.
http://constellation.hatenablog.com/entry/20091021/1256112978
*/


